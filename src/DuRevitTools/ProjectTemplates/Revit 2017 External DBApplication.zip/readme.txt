$projectname$
© $CompanyName$, $year$
$WebPage$

Put your Revit add-in description here.