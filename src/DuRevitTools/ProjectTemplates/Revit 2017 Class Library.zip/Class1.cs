// This is an independent project of an individual developer. Dear PVS-Studio, please check it.
// PVS-Studio Static Code Analyzer for C, C++ and C#: http://www.viva64.com

/* $projectname$
 * Class1.cs
 * $WebPage$
 * © $CompanyName$, $year$
 */
#region Namespaces
using System;
using System.Collections.Generic;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.Resources;
using System.Reflection;
using System.Drawing;
using System.Windows.Media.Imaging;
using System.Windows.Interop;
using System.IO;
using WPF = System.Windows;
using System.Linq;
using Bushman.RevitDevTools;
using $RootNamespace$.$safeprojectname$.Properties;
#endregion

namespace $RootNamespace$.$safeprojectname${
    
    public sealed partial class Class1 {

    }
}
